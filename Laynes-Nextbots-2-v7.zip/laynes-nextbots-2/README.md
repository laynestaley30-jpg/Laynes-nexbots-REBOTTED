# Laynes Nextbots 2 - Existing Game Handoff

This ZIP contains the original Laynes Nextbots game reorganized into separate HTML, CSS, and JavaScript files, plus an untouched copy of the original single-file game for reference.

## Project structure
- `index.html` - page structure and script/dependency loading. Open this file through a local web server or host it on GitHub Pages.
- `css/style.css` - original game's styles.
- `js/main.js` - original game's gameplay, UI, maps, modes, networking, and other logic.
- `reference/laynes-nextbots-original.html` - untouched original file. Use this to compare behavior if needed.

## Important existing-game context
The original game is a browser-based 3D nextbot chase game. It uses Three.js and PeerJS from CDN links. It already contains multiple maps, game modes, settings, touch/mobile controls, chat, and peer-to-peer online play. Inspect the actual source before changing or replacing any system.

## Sequel direction: Laynes Nextbots 2
The goal is to make a true sequel, not accidentally erase the original game's identity. The key direction established so far is:
- Multiplayer is a major priority. Improve the online experience and make it reliable.
- Keep the recognizable nextbot-chase gameplay and build on the original maps, modes, controls, and systems.
- Add more maps, nextbots, game modes, progression, coins, cosmetics, inventory/equipping, achievements, and leaderboards.
- Support players seeing and interacting with one another.
- Keep mobile/touch support.
- Plan the architecture so new features can be added without turning the project into one giant tangled file.

Previously requested feature idea to preserve in the sequel plan: a secret redeem code `1082056` that unlocks a Gold skin, Diamond skin, halo, and wings, plus an Inventory tab where players can view and equip unlocked cosmetics. This is a planned feature, not something this handoff claims is already implemented.

## Instructions for Claude
1. First inspect the entire project and the untouched original reference file. Explain briefly what systems already exist and how online play currently works.
2. Do not start by rewriting the game. Do not remove existing maps, modes, controls, settings, chat, nextbots, or other working features.
3. Treat `reference/laynes-nextbots-original.html` as the behavior reference. The split files are the working copy.
4. Before implementing a feature, identify the smallest set of files and systems that need changes. Reuse existing systems where possible.
5. Make changes in small, testable stages. After each stage, check for JavaScript errors and verify that existing gameplay still works.
6. Do not claim multiplayer works merely because a lobby UI exists. Test actual connections, player movement/state syncing, disconnects, and host/guest behavior.
7. Keep code token-efficient: concise explanations, minimal targeted edits, no unnecessary full-file rewrites, and no repeated summaries. Never sacrifice correctness or remove features just to save tokens.
8. Before making major architectural changes, explain the plan and wait for approval.

Start by auditing the existing game and proposing a practical Laynes Nextbots 2 development plan. Do not implement anything until the audit and plan are presented.
